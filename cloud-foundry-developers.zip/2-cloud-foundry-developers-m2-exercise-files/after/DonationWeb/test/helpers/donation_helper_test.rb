require 'test_helper'

class DonationHelperTest < ActionView::TestCase
end
